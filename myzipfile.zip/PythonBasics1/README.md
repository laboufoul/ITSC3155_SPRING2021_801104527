This repository includes code for ITSC 3155 Activity 3.0 - Python Basics
Dr. Nadia Najjar - UNCC
